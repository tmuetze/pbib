bootstrap-dropdown-checkbox
===========================

## Basic Dropdown Checkbox
![alt tag](http://acquisio.github.io/bootstrap-dropdown-checkbox/images/basic_dbc.png)

## Full Dropdown Checkbox with Header
![alt tag](http://acquisio.github.io/bootstrap-dropdown-checkbox/images/full_dbc.png)

## Documentation
Full documentation available at http://acquisio.github.io/bootstrap-dropdown-checkbox

## Build Assets
To run the build with grunt, do this inside the project folder:

```bash
npm install -g grunt-cli
npm install
grunt
```
